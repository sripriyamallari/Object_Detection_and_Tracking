import os
import tempfile
import streamlit as st
from ultralytics import YOLO

st.set_page_config(page_title="Object Detection & Tracking", page_icon="🎯")

st.title("🎯 Object Detection and Tracking")
st.write("Upload a video to detect and track objects using YOLO + ByteTrack.")

@st.cache_resource
def load_model():
    return YOLO("yolo26n.pt")

model = load_model()

uploaded_file = st.file_uploader(
    "Upload a video",
    type=["mp4", "avi", "mov", "mkv"]
)

if uploaded_file is not None:
    input_path = os.path.join(tempfile.gettempdir(), uploaded_file.name)

    with open(input_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    st.video(uploaded_file)

    if st.button("🚀 Detect & Track"):
        with st.spinner("Processing video... Please wait."):
            results = model.track(
                source=input_path,
                tracker="bytetrack.yaml",
                conf=0.25,
                save=True,
                stream=False
            )

        # Find the generated video without assuming a fixed folder name.
        search_roots = [
            "/content/runs",
            os.path.expanduser("~/.cache/ultralytics/runs")
        ]

        output_video = None
        for root in search_roots:
            if os.path.exists(root):
                for current_root, _, filenames in os.walk(root):
                    for name in filenames:
                        if name.lower().endswith(".mp4"):
                            candidate = os.path.join(current_root, name)
                            if output_video is None or os.path.getmtime(candidate) > os.path.getmtime(output_video):
                                output_video = candidate

        if output_video and os.path.exists(output_video):
            st.success("✅ Object detection and tracking completed!")
            st.video(output_video)

            with open(output_video, "rb") as f:
                st.download_button(
                    "⬇️ Download Tracked Video",
                    data=f,
                    file_name="tracked_output.mp4",
                    mime="video/mp4"
                )
        else:
            st.error("Output video was not found. Please run the detection again.")
else:
    st.info("Please upload an MP4 video to begin.")
