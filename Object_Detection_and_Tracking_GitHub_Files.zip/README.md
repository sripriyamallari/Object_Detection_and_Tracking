# Object Detection and Tracking

A computer vision project using YOLO and ByteTrack to detect and track objects in a video.

## Features
- YOLO object detection
- ByteTrack multi-object tracking
- Bounding boxes and tracking IDs
- Video output generation

## Files
- `app.py` - Streamlit web application
- `requirements.txt` - Python dependencies
- `README.md` - Project documentation
- `.gitignore` - Files not to upload to GitHub

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## How it works
1. Upload an MP4 video.
2. YOLO detects objects in each frame.
3. ByteTrack assigns tracking IDs.
4. The processed video is displayed for download.

## Model
The application uses the YOLO26n model from Ultralytics and downloads it automatically when needed.
